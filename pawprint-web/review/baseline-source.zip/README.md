# Pawprint — 当前项目副本

本网站已迁移到当前 chat。运行 `npm start` 后访问 http://127.0.0.1:8788/；互动页为 `/app.html?lang=en`，开发地址为 http://127.0.0.1:5174/。也可双击 `启动Pawprint.cmd`。

完整迁移记录见上一级目录的 `Pawprint迁移记录.md`。下方保留旧项目说明，其中端口、标题和旧首页描述以当前迁移记录为准。

当前互动页已经接入 OpenAI 人声回复：六种声音可选，默认 Verse；蓝老是男孩子，声音以明亮、轻快的少年感男声为方向；可选择自然陪伴、开心俏皮、温柔安慰三种语气，支持试听、重听、停止和自动朗读。麦克风只在点击后开启。声音为 AI 生成；正文与语音使用服务器现有的 `OPENAI_API_KEY`，可通过 `OPENAI_SPEECH_MODEL` 更换语音模型。官方接口说明：https://developers.openai.com/api/docs/guides/text-to-speech 。

官网 `/#keepsakes` 展示创作者在景德镇手作的两件陶瓷茶器，图片由内置 imagegen 基于实物照片分别重建。这是实体纪念周边方向的作品展示，尚未接入实体下单或制造流程。

# 蓝老 · 语音互动网站

> v2 增加了带账号和私有上传的宠物工作室。请先阅读 [部署与配置说明](./部署与配置说明.md)。完整工作室需运行 `npm run build` 和 `npm start`，访问 http://127.0.0.1:8787/studio.html 。下面的静态部署说明只适用于旧版蓝老演示，不适用于账号、照片或生成 API。当前服务器禁止 iframe 嵌入；如需嵌入须单独审查安全策略。

Three.js 直接加载附带的动画 GLB，不涉及 3DGS 转换。保留已认可的四个动作、原始颜色贴图与毛尖动画。

## 在电脑上运行

需要 Node.js。在此文件夹运行 `npm install`，然后 `npm run dev`，打开终端显示的本地地址。不要直接双击 HTML。

## 指令

| 说法 | 行为 |
| --- | --- |
| 蓝老，过来 | 朝当前镜头方向走近，到达后停止 |
| 蓝老，走一走 / 散步 | 在活动范围内走动 |
| 蓝老，跑步 | 在活动范围内小跑 |
| 蓝老，摇尾巴 | 播放摇尾巴动作 |
| 蓝老，跳一下 | 跳一次后站好 |
| 蓝老，停下 / 别动 | 停止移动，恢复站姿 |
| 蓝老，回去 | 回到出发点 |

点击“开启语音互动”后说一句话，每次识别结束自动停止聆听，不在后台持续监听。简体、繁体指令均可解析；默认识别语言是普通话 zh-CN。名字不是必需唤醒词。本版是明确指令匹配，不是通用语音聊天。

语音识别依赖浏览器 Web Speech API；部分浏览器虽提供接口，也可能无法连接识别服务。可能由浏览器服务商联网处理音频；网站本身不保存录音、不上传到自建服务器。不支持或拒绝麦克风权限时，可用按钮和文字。

## 放到你的网站

运行 `npm run build`，将 `dist` 内全部内容放入网站静态目录。支持作为独立网页，也可通过 iframe 嵌入；跨来源 iframe 使用麦克风需要上层网站允许 microphone。正式网站使用 HTTPS。当前版本仅在本机预览，未发布到公网。

`public/models/lanlao.glb` 为网页用模型；原始完整版 GLB 保留在上一级目录。网页模型使用 Meshopt 压缩，加载器已配套，不删减四个动作或替换毛色贴图。

## 验证与边界

`npm test` 检查指令解析；`npm run build` 检查生产构建。按钮、文字、到达后停止等可在页面测试；真实语音识别需用户本人授权麦克风并试说，不能把文字测试等同于麦克风测试。

模型较细致，低性能手机可能掉帧；本版限制渲染像素比，但未另做低模。毛发是预制的辅助动画，不是实时物理模拟。

技术参考：[Three.js GLTFLoader](https://threejs.org/docs/pages/GLTFLoader.html)、[AnimationMixer](https://threejs.org/docs/pages/AnimationMixer.html)、[MDN SpeechRecognition](https://developer.mozilla.org/en-US/docs/Web/API/SpeechRecognition)。
