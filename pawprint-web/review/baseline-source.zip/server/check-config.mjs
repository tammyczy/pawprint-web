import 'dotenv/config';
import {Tripo} from './tripo.mjs';
if(!process.env.TRIPO_API_KEY){console.log('请填写 .env 的 TRIPO_API_KEY。');process.exitCode=1;}
else{try{const result=await new Tripo(process.env.TRIPO_API_KEY).request('/account/balance');console.log(JSON.stringify({keyValid:true,availableCredits:result.balance,frozenCredits:result.frozen,configuredTestBudget:Number(process.env.TEST_BUDGET_CREDITS||0),paidGenerationEnabled:process.env.ALLOW_PAID_GENERATION==='true'},null,2));}catch{console.log('无法验证 API 余额，请检查密钥和网络。不显示密钥或原始响应。');process.exitCode=1;}}
