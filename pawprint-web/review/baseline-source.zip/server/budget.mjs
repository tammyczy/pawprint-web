// Keep reservations after failed/uncertain jobs until an operator reconciles billing.
export function reserveBudget(db,jobId,amount,limit){
 if(!Number.isFinite(amount)||amount<=0||!Number.isFinite(limit)||limit<0||limit>500)throw new Error('INVALID_BUDGET');
 db.exec('BEGIN IMMEDIATE');
 try{
  const existing=db.prepare('SELECT amount FROM budget_reservations WHERE job_id=?').get(jobId);
  if(existing){db.exec('COMMIT');return existing.amount;}
  const used=db.prepare('SELECT coalesce(sum(amount),0) AS total FROM budget_reservations').get().total;
  if(used+amount>limit)throw new Error('TEST_BUDGET_EXCEEDED');
  db.prepare('INSERT INTO budget_reservations(job_id,amount,created) VALUES(?,?,?)').run(jobId,amount,Date.now());db.exec('COMMIT');return amount;
 }catch(error){db.exec('ROLLBACK');throw error;}
}
