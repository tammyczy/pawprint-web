import 'dotenv/config';
import {readFile,writeFile,rename,open,unlink} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {execFile} from 'node:child_process';
import {promisify} from 'node:util';
import {openStore,updateJob} from './store.mjs';
import {Tripo,generationRequest,inspectGLB} from './tripo.mjs';
import {reserveBudget} from './budget.mjs';
import sharp from 'sharp';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..'),dataDir=path.join(root,'.data');
const id=process.argv[2],db=openStore(dataDir);
const job=db.prepare('SELECT * FROM jobs WHERE id=?').get(id||'');
if(!job||!['WAITING_APPROVAL','RUNNING','QUEUED','PROCESSING','PAUSED_NETWORK'].includes(job.status))throw new Error('任务不存在，或当前状态不允许运行。SUBMISSION_UNCERTAIN 必须先人工核对 Tripo 账单。');
if(!process.argv.includes('--confirm-tripo-charges')||process.env.ALLOW_PAID_GENERATION!=='true'||!process.env.TRIPO_API_KEY)throw new Error('尚未授权付费生成。请先配置 .env，并明确确认本任务的 Tripo 费用。');
// A single local process owns generation. A crash leaves a lock for deliberate recovery.
const lockPath=path.join(dataDir,'worker.lock');
let lock;try{lock=await open(lockPath,'wx');}catch{throw new Error('已有加工进程，或上次异常退出留下锁文件。请确认无运行进程后再恢复。');}
let data=JSON.parse(job.data),currentStep=job.step;
const tripo=new Tripo(process.env.TRIPO_API_KEY),dir=path.join(dataDir,'assets',job.id);
const save=(status,message)=>updateJob(db,id,{status,step:currentStep,data,message});
async function downloadAsset(value,maxBytes){
 const url=new URL(value);if(url.protocol!=='https:'||url.port||url.username||url.password||!(url.hostname==='tripo3d.ai'||url.hostname.endsWith('.tripo3d.ai')||url.hostname==='tripo-data.rg1.data.tripo3d.com'))throw new Error('UNAPPROVED_ASSET_HOST');
 const response=await fetch(url,{redirect:'error',signal:AbortSignal.timeout(180000)});
 if(!response.ok||Number(response.headers.get('content-length'))>maxBytes)throw new Error('ASSET_DOWNLOAD_FAILED');
 const chunks=[];let size=0;for await(const chunk of response.body){size+=chunk.length;if(size>maxBytes)throw new Error('ASSET_TOO_LARGE');chunks.push(chunk);}return Buffer.concat(chunks);
}
async function task(key,endpoint,body){
 currentStep=key;data.tasks??={};
 if(!data.tasks[key]){
  save('SUBMITTING',`正在提交 ${key}，请求可能产生 Tripo 费用。`);
  try{const taskId=await tripo.submit(endpoint,body);data.tasks[key]={id:taskId};save('RUNNING',`Tripo 正在处理 ${key}。`);}
  catch{save('SUBMISSION_UNCERTAIN','提交结果不确定；已停止自动重试，请站长核对 Tripo 任务和费用。');throw new Error('SUBMISSION_UNCERTAIN');}
 }
 const record=data.tasks[key];if(record.output)return record;
 save('RUNNING',`等待 Tripo 完成 ${key}。`);
 for(let attempt=0;attempt<720;attempt++){
  let result;try{result=await tripo.query(record.id);}catch{save('PAUSED_NETWORK','查询中断，任务编号已保存；恢复时只查询，不重复提交。');throw new Error('PAUSED_NETWORK');}
  if(result.status==='success'){record.output=result.output||{};record.credits=result.credits_consumed??(key==='rig_check'?0:null);save('RUNNING',`${key} 已完成。`);if(typeof record.credits!=='number'||Object.values(data.tasks).reduce((sum,t)=>sum+(t.credits||0),0)>75){save('FAILED','计费信息缺失或超出预期，已停止后续收费步骤，请核对账单。');throw new Error('BILLING_REVIEW_REQUIRED');}return record;}
  if(['failed','cancelled'].includes(result.status)){save('FAILED',`Tripo ${key} 未成功，请站长检查。`);throw new Error('PROVIDER_FAILED');}
  await new Promise(resolve=>setTimeout(resolve,5000));
 }
 save('PAUSED_NETWORK','等待超时，任务编号已保存，请稍后恢复查询。');throw new Error('POLL_TIMEOUT');
}
try{
 const balance=await tripo.request('/account/balance');
 if(typeof balance.balance!=='number'||balance.balance<100)throw new Error('API_BALANCE_BELOW_RESERVATION');
 // Fixed standard options currently total 65 credits. Reserve 100, never auto-refund.
 reserveBudget(db,id,100,Number(process.env.TEST_BUDGET_CREDITS||0));
 data.approvedAt??=Date.now();data.tokens??={};currentStep='upload';save('PROCESSING','正在将授权照片上传到 Tripo。');
 for(const [view,file]of Object.entries(data.photos))if(!data.tokens[view]){data.tokens[view]=await tripo.upload(await readFile(path.join(dir,file)),/\.jpe?g$/i.test(file)?'image/jpeg':'image/png');save('PROCESSING',`${view} 照片已上传。`);}
 let viewsTask;
 if(data.mode==='generated_views'){
  viewsTask=await task('multiview','/generation/image-to-multiview',{input:data.tokens.front});
  if(!data.viewsApprovedAt){
   currentStep='view_review';data.generatedViews={};save('PROCESSING','正在保存 AI 四视角，稍后需要你核对毛色与花纹。');
   const viewOutput=viewsTask.output.generate_multiview_image||viewsTask.output;
   for(const view of ['front','left','back','right']){const bytes=await downloadAsset(viewOutput[`${view}_view_url`],20*1024*1024);const file=`generated-${view}.png`;await sharp(bytes,{limitInputPixels:24000000}).rotate().resize(2048,2048,{fit:'inside',withoutEnlargement:true}).png().toFile(path.join(dir,file));data.generatedViews[view]=file;}
   save('VIEW_REVIEW','AI 四视角已生成。请检查侧面、背面毛色及花纹；确认后才继续生成 3D。');
  }
 }
 if(data.mode!=='generated_views'||data.viewsApprovedAt){
 const request=generationRequest(data.tokens,process.env.TRIPO_MODEL||'v3.1-20260211',viewsTask?.id);
 const generated=await task('generation',request.endpoint,request.body);
 // Preserve the colored geometry even if later rigging is unsuitable.
 if(!data.baseModelFile){
  const baseBytes=await downloadAsset(generated.output.model_url,150*1024*1024);
  data.baseReport=inspectGLB(baseBytes);await writeFile(path.join(dir,'base-model.glb'),baseBytes);
  data.baseModelFile='base-model.glb';data.modelFile=data.baseModelFile;save('RUNNING','彩色基础模型已保存，接下来检查四足绑定。');
 }
 const checked=await task('rig_check','/animations/rig-check',{input:generated.id});
 if(checked.output.riggable!==true||checked.output.rig_type!=='quadruped'){
  save('REVIEW_REQUIRED','模型未通过四足骨骼检查，需要人工检查照片和模型。');
 }else{
  const rigged=await task('rig','/animations/rig',{input:generated.id,model:'v2.5-20260210',rig_type:'quadruped',spec:'tripo',out_format:'glb'});
  const walked=await task('walk','/animations/retarget',{input:rigged.id,animation:'preset:quadruped:walk',out_format:'glb',bake_animation:true,export_with_geometry:true,animate_in_place:true});
  currentStep='download';save('PROCESSING','正在保存带行走动作的模型。');
  const bytes=await downloadAsset(walked.output.model_url,150*1024*1024),report=inspectGLB(bytes);await writeFile(path.join(dir,'model.tmp'),bytes);await rename(path.join(dir,'model.tmp'),path.join(dir,'model.glb'));
  data.modelFile='model.glb';data.report=report;currentStep='local_quality_check';save('PROCESSING','基础模型已保存，正在本机检查骨骼和材质。');
  if(process.env.BLENDER_PATH&&!process.argv.includes('--skip-blender')){
   try{await promisify(execFile)(process.env.BLENDER_PATH,['--background','--factory-startup','--python',path.join(root,'worker','inspect_model.py'),'--',path.join(dir,'model.glb'),path.join(dir,'quality.json')],{timeout:180000,maxBuffer:2*1024*1024,windowsHide:true});data.report.blender=JSON.parse(await readFile(path.join(dir,'quality.json'),'utf8'));}
   catch{data.report.blender={error:'本机 Blender 检查未完成，请人工检查。'};}
  }
  save('REVIEW_REQUIRED','基础模型和行走动作已生成。跑步、跳跃、摇尾巴和保色毛发仍需适配与视觉验收，尚未发布为完整宠物。');
 }
 }
 console.log('处理完成，查看网站任务状态。');
}catch(error){
 const latest=db.prepare('SELECT status FROM jobs WHERE id=?').get(id);
 if(!['SUBMISSION_UNCERTAIN','PAUSED_NETWORK','FAILED'].includes(latest.status))save('FAILED','处理未完成；已有任务编号和模型保留，请站长检查。');
 console.error('加工停止：',error.message);process.exitCode=1;
}finally{await lock.close();await unlink(lockPath);db.close();}
