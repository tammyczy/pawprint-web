export class Tripo {
 constructor(key,fetcher=fetch){this.key=key;this.fetcher=fetcher;}
 async request(endpoint,{body,method='GET'}={}){
  const multipart=body instanceof FormData;
  const response=await this.fetcher(`https://openapi.tripo3d.ai/v3${endpoint}`,{method,headers:{Authorization:`Bearer ${this.key}`,...(body&&!multipart?{'Content-Type':'application/json'}:{})},body:body?(multipart?body:JSON.stringify(body)):undefined,signal:AbortSignal.timeout(90000),redirect:'error'});
  if(!response.ok)throw new Error(`Tripo HTTP ${response.status}`);
  const result=await response.json();
  if(result.code!==0||!result.data)throw new Error(`Tripo API code ${Number(result.code)}`);
  return result.data;
 }
 async upload(bytes,mime='image/png'){const form=new FormData();form.set('file',new Blob([bytes],{type:mime}),mime==='image/jpeg'?'pet.jpg':'pet.png');const result=await this.request('/files',{method:'POST',body:form});if(!result.file_token)throw new Error('Missing file token');return result.file_token;}
 async submit(endpoint,body){const data=await this.request(endpoint,{method:'POST',body});if(typeof data.task_id!=='string')throw new Error('Missing task id');return data.task_id;}
 query(id){return this.request(`/tasks/${encodeURIComponent(id)}`);}
}
export function generationRequest(tokens,model,multiviewTaskId){
 const options={model,texture:true,pbr:true,face_limit:50000,texture_alignment:'original_image',texture_quality:'standard',geometry_quality:'standard',enable_image_autofix:false};
 if(multiviewTaskId)return {endpoint:'/generation/multiview-to-model',body:{...options,inputs:[{task_id:multiviewTaskId}]}};
 return Object.keys(tokens).length===1?{endpoint:'/generation/image-to-model',body:{...options,input:tokens.front}}:{endpoint:'/generation/multiview-to-model',body:{...options,inputs:Object.entries(tokens).map(([view,token])=>({[view]:token}))}};
}
export function inspectGLB(bytes){
 if(bytes.length<20||bytes.toString('ascii',0,4)!=='glTF'||bytes.readUInt32LE(4)!==2||bytes.readUInt32LE(8)!==bytes.length||bytes.readUInt32LE(16)!==0x4e4f534a)throw new Error('Invalid GLB');
 const length=bytes.readUInt32LE(12);if(length>bytes.length-20)throw new Error('Invalid GLB JSON');
 const document=JSON.parse(bytes.toString('utf8',20,20+length));
 for(const resource of [...document.buffers||[],...document.images||[]])if(resource.uri&&!resource.uri.startsWith('data:'))throw new Error('External GLB resources are not allowed');
 const animations=(document.animations||[]).map(x=>x.name||'Unnamed');
 return {animations,meshes:document.meshes?.length||0,materials:document.materials?.length||0,skins:document.skins?.length||0,joints:(document.skins||[]).reduce((n,s)=>n+s.joints.length,0)};
}
