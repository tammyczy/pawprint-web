export function createAIChat(petId=null){
 let history=[];
 return async text=>{
  const response=await fetch('/api/companion/chat',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text,petId,history})});
  const result=await response.json();
  if(!response.ok)throw new Error(result.error||'对话暂时不可用。');
  history=[...history,{role:'user',content:text},{role:'assistant',content:result.caption}].slice(-10);
  return result;
 };
}
