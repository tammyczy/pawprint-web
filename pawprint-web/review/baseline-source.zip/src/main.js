import './style.css';
import './speech.css';
import './i18n.css';
import './app-polish.css';
import {createIcons,PawPrint,ArrowUpRight,Mic,Hand,Footprints,Zap,Waves,Rabbit,CircleStop,RotateCcw} from 'lucide';
import * as THREE from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { MeshoptDecoder } from 'three/addons/libs/meshopt_decoder.module.js';
import { respond } from './companion.js';
import { createAIChat } from './ai-chat.js';
import { createVoicePanel } from './voice-ui.js';
import { createWebFur } from './web-fur.js';
import {initI18n,tr,locale} from './i18n.js';

const webFurMode=new URLSearchParams(location.search).get('fur')==='web';
let webFur;

const $=s=>document.querySelector(s), wrap=$('#canvas-wrap');
const state=$('#state'),reply=$('#reply'),mic=$('#mic');
const bubble=document.createElement('div');bubble.id='dog-speech';bubble.hidden=true;bubble.setAttribute('role','status');bubble.setAttribute('aria-live','polite');
const bubbleName=document.createElement('span');bubbleName.className='dog-speech-name';bubbleName.textContent='Lanlao';
const bubbleText=document.createElement('div');bubbleText.className='dog-speech-text';bubbleText.textContent='I’m here! Say hello.';bubble.append(bubbleName,bubbleText);document.querySelector('.stage').append(bubble);
function showSpeech(text){bubbleText.textContent=text.replace(/^(蓝老|Lanlao|Lanlao|蓝老)[：:]\s*/,'');}
new MutationObserver(()=>showSpeech(reply.textContent)).observe(reply,{childList:true,characterData:true,subtree:true});
let speechHead=null;const speechPosition=new THREE.Vector3();
const studioLink=document.querySelector('#studio-link')||document.createElement('a');studioLink.href='/studio.html';if(!studioLink.isConnected)document.querySelector('header').append(studioLink);
const furLink=document.querySelector('#fur-link')||document.createElement('a');furLink.href=webFurMode?'/app.html':'/app.html?fur=web';if(!furLink.isConnected)document.querySelector('.intro').append(furLink);
if(webFurMode){
 document.title='Lanlao · Animated web fur preview';
 const box=document.createElement('div');box.style.cssText='margin-top:18px;padding:14px;background:#e7ecdf;border-radius:12px;font-size:12px;line-height:1.7';
 const title=document.createElement('b');title.textContent='Preview: original GLB colors + live web fur';
 const toggle=document.createElement('button');toggle.id='fur-toggle';toggle.textContent='Web fur: on (compare)';toggle.disabled=true;toggle.style.cssText='display:block;margin:10px 0;padding:9px;border:1px solid #bdc9b1;background:#fafbf5;border-radius:7px;cursor:pointer';let active=true;toggle.onclick=()=>{active=!active;webFur?.setEnabled(active);toggle.textContent=`Web fur: ${active?'on':'off'} (compare)`;};
 const label=document.createElement('label');label.textContent='Fluff length ';const slider=document.createElement('input');slider.type='range';slider.min='3';slider.max='25';slider.value='14';slider.setAttribute('aria-label','Fluff length');slider.oninput=()=>webFur?.setLength(Number(slider.value)/1000);label.append(slider);
 const note=document.createElement('small');note.textContent='Fur is generated on the web, not stored in the GLB. Original animations remain; individual hairs are not physically simulated.';note.style.display='block';box.append(title,toggle,label,note);document.querySelector('.intro').append(box);
}
const settingsContent=document.querySelector('.settings-content');
const dialogueNote=document.createElement('small');dialogueNote.textContent='Checking AI conversation…';dialogueNote.style.display='block';document.querySelector('.voice-box').append(dialogueNote);
let aiConnected=false;
fetch('/api/health',{signal:AbortSignal.timeout(8000)}).then(r=>{if(!r.ok)throw new Error('Health check failed');return r.json();}).then(data=>{aiConnected=data.conversation==='openai';dialogueNote.textContent=tr(aiConnected?'aiOn':'aiOff');voicePlayback.setAvailable(data.speech==='openai');}).catch(()=>{dialogueNote.textContent=tr('chatOffline');voicePlayback.setAvailable(false);});
const languageLabel=document.createElement('label');languageLabel.textContent='Speech language ';const languageSelect=document.createElement('select');for(const [value,label] of [['en-US','English'],['zh-CN','中文'],['fr-FR','Français'],['es-ES','Español'],['de-DE','Deutsch'],['ja-JP','日本語'],['ko-KR','한국어']]){const option=document.createElement('option');option.value=value;option.textContent=label;languageSelect.append(option);}languageLabel.append(languageSelect);document.querySelector('.voice-box').append(languageLabel);
settingsContent.append(languageLabel);
const voicePlayback=createVoicePanel({container:settingsContent,locale,beforeSpeak:()=>recognition?.abort()});
let ready=false;
const voiceLocales={zh:'zh-CN',en:'en-US',fr:'fr-FR'};
const lucideIcons={PawPrint,ArrowUpRight,Mic,Hand,Footprints,Zap,Waves,Rabbit,CircleStop,RotateCcw};
const renderIcons=()=>createIcons({icons:lucideIcons,attrs:{'stroke-width':1.7}});
initI18n('home',()=>{languageSelect.value=voiceLocales[locale()];languageLabel.firstChild.textContent=tr('speechLanguage');voicePlayback.render();dialogueNote.textContent=tr(aiConnected?'aiOn':'aiOff');const studioText=[...studioLink.childNodes].find(n=>n.nodeType===Node.TEXT_NODE);if(studioText)studioText.textContent=tr('createPet')+' ';else studioLink.prepend(document.createTextNode(tr('createPet')+' '));furLink.textContent=tr(webFurMode?'furBack':'furTry');bubbleName.textContent=tr('brand');if(ready){state.textContent=tr('stateReady');reply.textContent=`${tr('brand')}: ${tr('hello')}`;}for(const button of document.querySelectorAll('[data-command]')){const label=button.querySelector('span');if(label)label.textContent=tr(button.dataset.command);const hint=button.querySelector('small');if(hint)hint.textContent=tr(`hint_${button.dataset.command}`);}renderIcons();});
let renderer,mixer,model,activeAction,mode='stop',destination=null;
const actions={},rest=[],home=new THREE.Vector3(0,0,0);
const scene=new THREE.Scene();scene.background=new THREE.Color('#e8e9df');
const camera=new THREE.PerspectiveCamera(35,1,.05,50);
camera.position.set(-1.5,1.15,2.8);
try{renderer=new THREE.WebGLRenderer({antialias:true,alpha:false});}
catch(e){$('#loading').innerHTML='<b>This browser cannot display 3D right now.</b><span>Enable hardware acceleration or try a browser with WebGL support.</span>';throw e;}
renderer.setPixelRatio(Math.min(devicePixelRatio,1.6));renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFShadowMap;
renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.12;
wrap.append(renderer.domElement);
const controls=new OrbitControls(camera,renderer.domElement);controls.target.set(0,.43,0);controls.enableDamping=true;controls.enablePan=false;controls.minDistance=1.5;controls.maxDistance=5;controls.maxPolarAngle=Math.PI/2-.04;
controls.saveState();$('#reset-view').onclick=()=>controls.reset();
scene.add(new THREE.HemisphereLight(0xfff9ed,0x7d8b70,2.1));
const sun=new THREE.DirectionalLight(0xfff2de,3.0);sun.position.set(-3,5,3);sun.castShadow=true;sun.shadow.mapSize.set(1024,1024);sun.shadow.camera.left=-3;sun.shadow.camera.right=3;sun.shadow.camera.top=3;sun.shadow.camera.bottom=-3;sun.shadow.normalBias=.025;scene.add(sun);
const fill=new THREE.DirectionalLight(0xffffff,1);fill.position.set(3,2,-2);scene.add(fill);
const ground=new THREE.Mesh(new THREE.PlaneGeometry(200,200),new THREE.MeshStandardMaterial({color:'#e8e9df',roughness:1}));ground.rotation.x=-Math.PI/2;ground.position.y=-.009;ground.receiveShadow=true;scene.add(ground);
const dog=new THREE.Group();scene.add(dog);
const loader=new GLTFLoader().setMeshoptDecoder(MeshoptDecoder);
loader.load(`${import.meta.env.BASE_URL}models/${webFurMode?'lanlao-base.glb':'lanlao.glb'}`,gltf=>{
 model=gltf.scene;dog.add(model);
 speechHead=model.getObjectByName('Head');
 model.traverse(o=>{if(o.isMesh){o.castShadow=true;o.receiveShadow=false;o.frustumCulled=false;}if(o.isBone)rest.push({o,p:o.position.clone(),q:o.quaternion.clone(),s:o.scale.clone()});});
 mixer=new THREE.AnimationMixer(model);
 if(webFurMode){webFur=createWebFur(model,{layers:matchMedia('(max-width:760px)').matches?6:10});$('#fur-toggle').disabled=webFur.count===0;document.querySelector('footer>span:last-child').textContent='Web fur preview · Original colors and four animations';}
 for(const clip of gltf.animations)actions[clip.name]=mixer.clipAction(clip);
 const required=['Walk_Refined','Run_Trot_Natural','Tail_Wag_Natural','Jump_Natural'];
 if(required.some(n=>!actions[n])){fail('The model is missing required animations. Please use the included Lanlao GLB.');return;}
 mixer.addEventListener('finished',e=>{if(e.action===activeAction)execute('stop',true);});
 ready=true;$('#loading').classList.add('hidden');document.querySelectorAll('[data-command],#send').forEach(b=>b.disabled=false);
 mic.disabled=!Recognition;state.textContent=tr('stateReady');reply.textContent=`${tr('brand')}: ${tr('hello')}`;bubble.hidden=false;
},e=>{if(e.total)$('#progress').textContent=`Loading · ${Math.round(e.loaded/e.total*100)}%`;},()=>fail('The model could not load. Please refresh and check that models/lanlao.glb is present.'));
function fail(message){$('#loading').innerHTML='';const b=document.createElement('b');b.textContent=message;$('#loading').append(b);state.textContent='Loading failed';}
function play(name,once=false){
 const next=actions[name];if(activeAction===next&&next.isRunning())return;
 const previous=activeAction;next.reset().setEffectiveTimeScale(1).setEffectiveWeight(1);next.setLoop(once?THREE.LoopOnce:THREE.LoopRepeat,once?1:Infinity);next.clampWhenFinished=once;next.play();
 if(previous&&previous!==next){previous.fadeOut(.2);next.fadeIn(.2);}activeAction=next;
}
function execute(command,quiet=false){
 if(!ready)return;destination=null;mode=command;
 const labels={come:tr('action_come'),home:tr('action_home'),walk:tr('action_walk'),run:tr('action_run'),wag:tr('action_wag'),jump:tr('action_jump'),stop:tr('action_stop')};
 if(command==='stop'){mixer.stopAllAction();activeAction=null;}
 else if(command==='come'||command==='home'){
  destination=command==='home'?home.clone():new THREE.Vector3(camera.position.x,0,camera.position.z).normalize().multiplyScalar(.85);
  play('Walk_Refined');
 }else play({walk:'Walk_Refined',run:'Run_Trot_Natural',wag:'Tail_Wag_Natural',jump:'Jump_Natural'}[command],command==='jump'||command==='wag');
 state.textContent=labels[command];if(!quiet)reply.textContent=`${tr('brand')}: ${labels[command]}.`;
 document.querySelectorAll('[data-command]').forEach(b=>{b.classList.toggle('active',b.dataset.command===command);b.setAttribute('aria-pressed',String(b.dataset.command===command));});
}
const askAI=createAIChat();let answering=false;
async function accept(text){if(answering)return;voicePlayback.stop();answering=true;$('#send').disabled=true;reply.textContent=`${tr('brand')}: ${tr('thinking')}`;
 try{const answer=await askAI(text);if(answer.action)execute(answer.action);reply.textContent=`${tr('brand')}: ${answer.caption}`;void voicePlayback.speak(answer.caption);aiConnected=true;dialogueNote.textContent=tr('aiOn');$('#command-text').value='';}
 catch(error){const answer=respond(text,locale());if(answer.action)execute(answer.action);reply.textContent=`${tr('brand')}: ${answer.caption}`;void voicePlayback.speak(answer.caption);dialogueNote.textContent=tr('chatOffline');}
 finally{answering=false;$('#send').disabled=!ready;}}
document.querySelectorAll('[data-command]').forEach(b=>b.onclick=()=>{voicePlayback.stop();execute(b.dataset.command);if(b.dataset.command!=='stop')void voicePlayback.speak(tr(`action_${b.dataset.command}`)+'.');});
$('#command-form').onsubmit=e=>{e.preventDefault();const v=$('#command-text').value.trim();if(v)accept(v);};

// Explicit, one-utterance microphone sessions. No background listening or audio storage.
const Recognition=window.SpeechRecognition||window.webkitSpeechRecognition;
let recognition,listening=false,voiceError=false;
if(!Recognition)$('#voice-status').textContent='Voice recognition is unavailable here. Use the buttons or type instead.';
mic.onclick=()=>{
 if(!Recognition||!ready)return;
 if(listening){recognition.stop();return;}
 voicePlayback.stop();
 recognition=new Recognition();recognition.lang=languageSelect.value;recognition.continuous=false;recognition.interimResults=true;recognition.maxAlternatives=1;voiceError=false;
 recognition.onstart=()=>{listening=true;mic.classList.add('listening');mic.textContent=tr('listening');$('#voice-status').textContent=tr('listening');showSpeech(tr('listening'));};
 recognition.onresult=e=>{for(let i=e.resultIndex;i<e.results.length;i++){const t=e.results[i][0].transcript;$('#voice-status').textContent=`${tr('heard')}${t}`;if(e.results[i].isFinal)accept(t);}};
 recognition.onerror=e=>{voiceError=true;const errors={'not-allowed':'Microphone access was not granted. Allow it in your browser and try again.','audio-capture':'No microphone is available. Check your device.','network':'Speech recognition could not connect. Please type or use a button.','no-speech':'I didn’t catch that. Try again.','service-not-allowed':'Speech recognition is unavailable here. Please type or use a button.','aborted':'Listening stopped.'};$('#voice-status').textContent=errors[e.error]||`Voice is unavailable (${e.error}). Please type or use a button.`;};
 recognition.onend=()=>{listening=false;mic.classList.remove('listening');mic.innerHTML=tr('micStart');renderIcons();if(!voiceError)$('#voice-status').textContent=tr('micStatus');};
 try{recognition.start();}catch{listening=false;$('#voice-status').textContent='Voice could not start. Please try again or type instead.';}
};
document.addEventListener('visibilitychange',()=>{if(document.hidden){if(recognition)recognition.abort();voicePlayback.stop();}});
new ResizeObserver(()=>{const {width,height}=wrap.getBoundingClientRect();renderer.setSize(width,height);camera.aspect=width/height;camera.updateProjectionMatrix();}).observe(wrap);
let lastTime=performance.now(),pathTime=0;
renderer.setAnimationLoop(()=>{
 const now=performance.now(),dt=Math.min((now-lastTime)/1000,.05);lastTime=now;controls.update();
 if(!document.hidden&&ready){
  if(mixer)mixer.update(dt);
  if(webFur)webFur.update(dt,mode);
  if(mode==='stop'){
   for(const r of rest){r.o.position.lerp(r.p,1-Math.exp(-dt*12));r.o.quaternion.slerp(r.q,1-Math.exp(-dt*12));r.o.scale.lerp(r.s,1-Math.exp(-dt*12));}
   model.traverse(o=>{if(o.morphTargetInfluences)o.morphTargetInfluences.forEach((v,i)=>o.morphTargetInfluences[i]=v*Math.exp(-dt*12));});
  }
  if(destination){const dir=destination.clone().sub(dog.position);dir.y=0;const d=dir.length();if(d<.015)execute('stop',true);else{dir.normalize();dog.position.addScaledVector(dir,Math.min(d,.275*dt));const q=new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),Math.atan2(dir.z,-dir.x));dog.quaternion.slerp(q,1-Math.exp(-dt*8));}}
  else if(mode==='walk'||mode==='run'){
   const speed=mode==='walk'?.275:.87;pathTime+=dt*speed/.62;
   const target=new THREE.Vector3(Math.cos(pathTime)*.62,0,Math.sin(pathTime)*.32);
   const dir=target.clone().sub(dog.position);if(dir.length()>.015){dir.normalize();dog.position.addScaledVector(dir,Math.min(speed*dt,dog.position.distanceTo(target)));dog.quaternion.slerp(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,1,0),Math.atan2(dir.z,-dir.x)),1-Math.exp(-dt*5));}
  }
 }
 renderer.render(scene,camera);
 if(ready){
  if(speechHead){speechHead.getWorldPosition(speechPosition);speechPosition.y+=.24;}else{dog.getWorldPosition(speechPosition);speechPosition.y+=1.0;}
  speechPosition.project(camera);
  const width=wrap.clientWidth,height=wrap.clientHeight,half=Math.min(142,(width-32)/2);
  const x=THREE.MathUtils.clamp((speechPosition.x*.5+.5)*width,half+12,width-half-12);
  const y=THREE.MathUtils.clamp((-.5*speechPosition.y+.5)*height,bubble.offsetHeight+58,height-56);
  bubble.style.left=`${x}px`;bubble.style.top=`${y}px`;
 }
});

import './design-system.css';
