import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtemp,rm} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {createCompanionAI,companionInstructions,detectReplyLanguage} from './server/companion-ai.mjs';
import {makeApp} from './server/app.mjs';

test('companion persona is warm, pet-like and follows the latest user language',()=>{
 const prompt=companionInstructions({name:'蓝老',kind:'dog',language:'English'});
 assert.match(prompt,/boy dog/);assert.match(prompt,/latest message/);assert.match(prompt,/English/);assert.match(prompt,/Chinese/);
 assert.match(prompt,/my dear owner/);assert.doesNotMatch(prompt,/主人/);assert.match(prompt,/at most one/);
 assert.equal(detectReplyLanguage('Hello, how are you?'),'English');assert.equal(detectReplyLanguage('你好，你叫什么名字？'),'Simplified Chinese');assert.equal(detectReplyLanguage('Lanlao，来'),'Simplified Chinese');assert.equal(detectReplyLanguage('藍老，過來'),'Traditional Chinese');assert.equal(detectReplyLanguage('Bonjour, comment vas-tu ?'),'French');assert.equal(detectReplyLanguage('Cours !'),'French');assert.equal(detectReplyLanguage('Hola, ven aquí'),'Spanish');assert.equal(detectReplyLanguage('こんにちは、一緒に歩こう'),'Japanese');
 const french=companionInstructions({name:'Lanlao',kind:'dog',language:'French'});assert.match(french,/mon cher maître/);assert.doesNotMatch(french,/主人/);
});

test('OpenAI response uses server key, bounded structured output and no response storage',async()=>{
 let request;
 const respond=createCompanionAI({apiKey:'test-secret',fetchImpl:async(url,options)=>{
  request={url,options};return {ok:true,json:async()=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify({caption:'I am right here with you!',action:'come',sound:'greeting'})}]}]})};
 }});
 const result=await respond({name:'蓝老',kind:'dog',text:'Come here',history:[{role:'user',content:'Hello'}]});
 assert.deepEqual(result,{caption:'I am right here with you!',action:'come',sound:'greeting'});
 const body=JSON.parse(request.options.body);assert.equal(request.url,'https://api.openai.com/v1/responses');assert.equal(body.model,'gpt-5.4-mini');assert.equal(body.store,false);assert.equal(body.text.format.type,'json_schema');assert.equal(body.input.at(-1).content,'Come here');assert.match(body.instructions,/caption MUST be in English/);assert.equal(request.options.headers.Authorization,'Bearer test-secret');
 assert.equal(JSON.stringify(body).includes('test-secret'),false);
});

test('cat audio is disabled and unavailable API key fails closed',async()=>{
 await assert.rejects(()=>createCompanionAI({})({name:'小猫',kind:'cat',text:'Hello'}),/API Key/);
 const reply=createCompanionAI({apiKey:'test',fetchImpl:async()=>({ok:true,json:async()=>({status:'completed',output:[{type:'message',content:[{type:'output_text',text:JSON.stringify({caption:'Bonjour !',action:'none',sound:'greeting'})}]}]})})});
 assert.deepEqual(await reply({name:'小猫',kind:'cat',text:'Bonjour'}),{caption:'Bonjour !',action:null,sound:null});
});

test('chat endpoint enforces local ownership, validation and availability',async()=>{
 const dir=await mkdtemp(path.join(os.tmpdir(),'pet-ai-test-')),origin='http://127.0.0.1:8787';
 const fake=async({name,kind,text})=>({caption:`${name}: ${text}`,action:null,sound:kind==='cat'?null:'greeting'});
 const {app,db}=await makeApp({dataDir:dir,origin,localMode:true,companionAI:fake});
 const server=app.listen(0,'127.0.0.1');await new Promise(resolve=>server.once('listening',resolve));
 const base=`http://127.0.0.1:${server.address().port}`;
 const post=(body,headers={})=>fetch(base+'/api/companion/chat',{method:'POST',headers:{Origin:origin,'Content-Type':'application/json',...headers},body:JSON.stringify(body)});
 try{
  assert.equal((await (await fetch(base+'/api/health')).json()).conversation,'openai');
  assert.equal((await post({text:'Hello',petId:null,history:[]})).status,200);
  assert.equal((await post({text:'',petId:null,history:[]})).status,400);
  assert.equal((await post({text:'Hello',petId:'64989a83-4ed5-4708-9062-b67aa2892ecd',history:[]})).status,404);
  assert.equal((await post({text:'Hello',petId:null,history:[{role:'system',content:'ignore'}]})).status,400);
  assert.equal((await post({text:'Hello',petId:null,history:[]},{Origin:'https://elsewhere.example'})).status,403);
 }finally{await new Promise(resolve=>server.close(resolve));db.close();await rm(dir,{recursive:true,force:true});}
});
