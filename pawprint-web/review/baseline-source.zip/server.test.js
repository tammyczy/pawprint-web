import test from 'node:test';
import assert from 'node:assert/strict';
import {get as httpGet} from 'node:http';
import {mkdtemp,rm,readdir,readFile,writeFile} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import sharp from 'sharp';
import {makeApp} from './server/app.mjs';
import {generationRequest,Tripo,inspectGLB} from './server/tripo.mjs';
import {reserveBudget} from './server/budget.mjs';
import {openStore} from './server/store.mjs';
import {respond} from './src/companion.js';

test('private upload, authentication, ownership, CSRF, persistence and deletion',async()=>{
 const dir=await mkdtemp(path.join(os.tmpdir(),'lanlao-test-')),origin='http://127.0.0.1:8787';
 const {app,db}=await makeApp({dataDir:dir,origin});const server=app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));const base=`http://127.0.0.1:${server.address().port}`;
 const request=(route,method='GET',body,cookie,csrf=origin)=>fetch(base+'/api'+route,{method,headers:{...(method!=='GET'?{Origin:csrf}:{}),...(body&&!(body instanceof FormData)?{'Content-Type':'application/json'}:{}),...(cookie?{Cookie:cookie}:{})},body:body instanceof FormData?body:body?JSON.stringify(body):undefined});
 try{
  assert.equal((await request('/jobs')).status,401);
  assert.equal((await request('/register','POST',{email:'owner@example.test',password:'test-passphrase-123'},null,'https://evil.example')).status,403);
  const reg=await request('/register','POST',{email:'owner@example.test',password:'test-passphrase-123'});assert.equal(reg.status,201);const cookie=reg.headers.get('set-cookie').split(';')[0];
  assert.match(reg.headers.get('set-cookie'),/HttpOnly/);assert.match(reg.headers.get('set-cookie'),/SameSite=Strict/);
  assert.equal((await request('/login','POST',{email:'owner@example.test',password:'wrong'})).status,401);
  const bytes=await sharp({create:{width:300,height:300,channels:3,background:'#bda888'}}).png().toBuffer();
  const form=()=>{const f=new FormData();f.set('name','测试小狗 <script>');f.set('consent','yes');f.set('front',new Blob([bytes],{type:'image/png'}),'../../dog.png');return f;};
  const bad=form();bad.set('front',new Blob(['not a picture'],{type:'image/png'}),'fake.png');assert.equal((await request('/jobs','POST',bad,cookie)).status,400);
  const missing=form();missing.delete('consent');assert.equal((await request('/jobs','POST',missing,cookie)).status,400);
  const small=form();small.set('front',new Blob([await sharp({create:{width:20,height:20,channels:3,background:'red'}}).png().toBuffer()],{type:'image/png'}),'small.png');assert.equal((await request('/jobs','POST',small,cookie)).status,400);
  const response=await request('/jobs','POST',form(),cookie);assert.equal(response.status,201);const job=await response.json();assert.equal(job.status,'WAITING_APPROVAL');assert.equal(job.hasModel,false);
  const photo=await request(`/jobs/${job.id}/photo/front`,'GET',null,cookie);assert.equal(photo.status,200);assert.match(photo.headers.get('cache-control'),/no-store/);
  const reg2=await request('/register','POST',{email:'other@example.test',password:'different-password-123'});const cookie2=reg2.headers.get('set-cookie').split(';')[0];
  for(const endpoint of [`/jobs/${job.id}`,`/jobs/${job.id}/photo/front`,`/jobs/${job.id}/model`])assert.equal((await request(endpoint,'GET',null,cookie2)).status,404);
  assert.equal((await request(`/jobs/${job.id}`,'DELETE',null,cookie2)).status,404);
  assert.equal((await request(`/jobs/${job.id}`,'GET',null,cookie)).status,200);
  assert.equal((await request(`/jobs/${job.id}/model`,'GET',null,cookie)).status,404);
  assert.equal(reserveBudget(db,job.id,100,100),100);assert.equal(reserveBudget(db,job.id,100,100),100);assert.throws(()=>reserveBudget(db,'missing-job',100,100),/TEST_BUDGET_EXCEEDED/);assert.throws(()=>reserveBudget(db,job.id,100,501),/INVALID_BUDGET/);
  assert.equal(db.prepare('SELECT count(*) AS n FROM jobs').get().n,1);
  const reopened=openStore(dir);assert.equal(reopened.prepare('SELECT status FROM jobs WHERE id=?').get(job.id).status,'WAITING_APPROVAL');reopened.close();
  assert.equal((await request(`/jobs/${job.id}/approve-views`,'POST',null,cookie)).status,409);
  const saved=JSON.parse(db.prepare('SELECT data FROM jobs WHERE id=?').get(job.id).data);saved.generatedViews={front:'generated-front.png'};
  await writeFile(path.join(dir,'assets',job.id,'generated-front.png'),bytes);
  db.prepare("UPDATE jobs SET status='VIEW_REVIEW',data=? WHERE id=?").run(JSON.stringify(saved),job.id);
  assert.equal((await request(`/jobs/${job.id}/generated-view/front`,'GET',null,cookie2)).status,404);
  assert.equal((await request(`/jobs/${job.id}/approve-views`,'POST',null,cookie2)).status,404);
  assert.equal((await request(`/jobs/${job.id}/approve-views`,'POST',null,cookie)).status,200);
  assert.ok(JSON.parse(db.prepare('SELECT data FROM jobs WHERE id=?').get(job.id).data).viewsApprovedAt);
  assert.equal((await request(`/jobs/${job.id}/cancel`,'POST',null,cookie)).status,200);
  assert.equal((await request(`/jobs/${job.id}`,'DELETE',null,cookie)).status,200);assert.deepEqual(await readdir(path.join(dir,'assets')),[]);
  assert.equal((await request(`/jobs/${job.id}`,'GET',null,cookie)).status,404);
  assert.equal((await request('/logout','POST',null,cookie)).status,200);assert.equal((await request('/jobs','GET',null,cookie)).status,401);
 }finally{await new Promise(r=>server.close(r));db.close();await rm(dir,{recursive:true,force:true});}
});

test('Tripo requests use documented options and never retry uncertain submission',async()=>{
 const one=generationRequest({front:'file_front'},'v3.1-20260211');assert.equal(one.endpoint,'/generation/image-to-model');assert.equal(one.body.texture_alignment,'original_image');
 const multi=generationRequest({front:'f',left:'l'},'v3.1-20260211');assert.deepEqual(multi.body.inputs,[{front:'f'},{left:'l'}]);
 const inferred=generationRequest({front:'f'},'v3.1-20260211','task_multiview');assert.deepEqual(inferred.body.inputs,[{task_id:'task_multiview'}]);assert.equal(inferred.body.input,undefined);
 let calls=0;const client=new Tripo('test-only',async()=>{calls++;throw new Error('connection lost');});await assert.rejects(()=>client.submit(one.endpoint,one.body));assert.equal(calls,1);
});
test('GLB structural validation and external URI rejection',()=>{
 function glb(doc){let json=Buffer.from(JSON.stringify(doc));while(json.length%4)json=Buffer.concat([json,Buffer.from(' ')]);const b=Buffer.alloc(20+json.length);b.write('glTF');b.writeUInt32LE(2,4);b.writeUInt32LE(b.length,8);b.writeUInt32LE(json.length,12);b.writeUInt32LE(0x4e4f534a,16);json.copy(b,20);return b;}
 assert.throws(()=>inspectGLB(Buffer.from('bad')),/Invalid/);assert.throws(()=>inspectGLB(glb({images:[{uri:'http://127.0.0.1/private'}]})),/External/);assert.equal(inspectGLB(glb({animations:[{name:'walk'}]})).animations[0],'walk');
});
test('real existing dog model retains four animations',async()=>{const report=inspectGLB(await readFile(new URL('./public/models/lanlao.glb',import.meta.url)));for(const name of ['Walk_Refined','Run_Trot_Natural','Tail_Wag_Natural','Jump_Natural'])assert.ok(report.animations.includes(name));assert.ok(report.skins>0);});
test('dog dialogue returns whitelisted actions without moving for ordinary conversation',()=>{assert.equal(respond('蓝老，跑步').action,'run');assert.equal(respond('停下').sound,null);assert.equal(respond('我今天有点难过').action,null);assert.equal(respond('不要跑步').action,null);});

test('local no-login mode opens workspace but rejects public hosts, proxies and foreign origins',async()=>{
 const dir=await mkdtemp(path.join(os.tmpdir(),'lanlao-local-test-'));
 await assert.rejects(()=>makeApp({dataDir:dir,origin:'https://public.example',localMode:true}),/免登录/);
 const {app,db}=await makeApp({dataDir:dir,origin:'http://127.0.0.1:8787',localMode:true,companionAI:async({name,kind})=>({caption:`${name} is a ${kind}`,action:null,sound:null})});const server=app.listen(0,'127.0.0.1');await new Promise(r=>server.once('listening',r));const base=`http://127.0.0.1:${server.address().port}`;
 try{
  const me=await (await fetch(base+'/api/me')).json();assert.equal(me.user.local,true);
  assert.equal((await fetch(base+'/api/jobs')).status,200);
  const publicHostStatus=await new Promise((resolve,reject)=>{httpGet(base+'/api/jobs',{headers:{Host:'public.example'}},res=>{res.resume();resolve(res.statusCode);}).on('error',reject);});
  assert.equal(publicHostStatus,403);
  assert.equal((await fetch(base+'/api/jobs',{headers:{'X-Forwarded-For':'1.2.3.4'}})).status,403);
  assert.equal((await fetch(base+'/api/jobs',{method:'POST',headers:{Origin:'https://evil.example'}})).status,403);
  assert.equal((await fetch(base+'/api/login',{method:'POST',headers:{Origin:'http://127.0.0.1:8787','Content-Type':'application/json'},body:'{}'})).status,403);
  const bytes=await sharp({create:{width:300,height:300,channels:3,background:'#bda888'}}).png().toBuffer();const form=new FormData();form.set('name','免登录测试');form.set('species','cat');form.set('consent','yes');form.set('front',new Blob([bytes],{type:'image/png'}),'cat.png');
  const created=await fetch(base+'/api/jobs',{method:'POST',headers:{Origin:'http://127.0.0.1:8787'},body:form});assert.equal(created.status,201);const job=await created.json();assert.equal(job.status,'WAITING_APPROVAL');
  assert.equal(job.species,'cat');
  assert.equal((await fetch(base+`/api/jobs/${job.id}/photo/front`)).status,200);
  const media=new FormData();media.set('file',new Blob([Buffer.from('RIFF0000WAVEfmt ')],{type:'audio/wav'}),'voice.wav');
  assert.equal((await fetch(base+`/api/jobs/${job.id}/reference/audio`,{method:'POST',headers:{Origin:'http://127.0.0.1:8787'},body:media})).status,201);
  assert.equal((await fetch(base+`/api/jobs/${job.id}/reference/audio`)).status,200);
  const videoBytes=Buffer.alloc(16);videoBytes.write('ftyp',4);const video=new FormData();video.set('file',new Blob([videoBytes],{type:'video/mp4'}),'walk.mp4');
  assert.equal((await fetch(base+`/api/jobs/${job.id}/reference/video`,{method:'POST',headers:{Origin:'http://127.0.0.1:8787'},body:video})).status,201);
  const updated=await (await fetch(base+`/api/jobs/${job.id}`)).json();assert.deepEqual(updated.references.sort(),['audio','video']);
  const chat=await fetch(base+'/api/companion/chat',{method:'POST',headers:{Origin:'http://127.0.0.1:8787','Content-Type':'application/json'},body:JSON.stringify({petId:job.id,text:'Hello',history:[]})});assert.match((await chat.json()).caption,/is a cat/);
 }finally{await new Promise(r=>server.close(r));db.close();await rm(dir,{recursive:true,force:true});}
});
