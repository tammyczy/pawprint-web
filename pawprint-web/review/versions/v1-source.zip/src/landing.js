import './landing.css';
import {createIcons,PawPrint,ArrowUpRight,ArrowDown,ScanFace,Footprints,MessageCircleHeart,ExternalLink} from 'lucide';

createIcons({icons:{PawPrint,ArrowUpRight,ArrowDown,ScanFace,Footprints,MessageCircleHeart,ExternalLink},attrs:{'stroke-width':1.7}});

import './experience.js';
